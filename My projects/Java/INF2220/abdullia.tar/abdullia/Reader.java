import java.util.*;
import java.io.*;
import java.sql.Timestamp;


public class Reader
{

	private Scanner scan;  // declare a scanner object
	
	
	Spelling sp = new Spelling(); // create and object of spelling class to access its methods.
	private BinSearchTree dictionary;  // declaring a binSearchTree pointer
	

	/**
	This method read a file called "dictinary.txt" and puts into the dictionary(Binary Search Tree).  deletes and re-addes the "busybody" word.
	*/

	public void readFile(){  
	    String filename = "dictionary.txt";
		try 
		{
		    scan = new Scanner(new File(filename));
			String data;  
            while (scan.hasNext())
            {
				data = scan.next();
				
				if (dictionary == null) {
					dictionary = new BinSearchTree(data);
				} else {
					dictionary.insert(data);
				}
			}
		}
		catch(FileNotFoundException ioexception){
			System.out.println("FileNotFoundException");
			System.exit(0);
		}
		catch (IndexOutOfBoundsException e){
			System.out.println("IndexOutOfBoundsException!");
		}
		catch(NumberFormatException e){
			System.out.println("Number Format Exception.....");
		}

			dictionary.delete("busybody"); 
			dictionary.insert("busybody");
			
			userInterface();
	}
	 /**
			it prompts the user to give a word to search it or to press "h" for help, if the user press "q" it Quits the program and prints statistics.
			if the word is not found it calls a method in the spelling class to further search the word.
	 */
	public void userInterface(){
		scan = new Scanner(System.in);
		while(true) {
			System.out.print("Enter Word to look up or h for help:- ");	
			String input = scan.nextLine().toLowerCase();
			if (input.equals("h")) {
				menu();
			}if (input.equals("")) {
				System.out.println("You did not typed a word!  Please type ");
				continue;
			}
			if (input.equals("q")) {
				System.out.println("\nPrinting Statistics and Quit the Program ! ");
				dictionary.printStatistics();
				System.exit(0);
			}else{
				String str = dictionary.search(input);
				if(str != null){
					System.out.println(input + " is spelled correctly!");
				}else{
					sp.findWord(input, dictionary);	
				}	
			
			}
		}
	}

	public void menu(){  // Displays the Menu.
		System.out.println();
		System.out.println(" [q] \t Terminate the program");
		System.out.println(" [h] \t Menu");
		System.out.println(" **************************************** \n");
		userInterface();
	
	}


}