import java.util.*;
import java.sql.Timestamp;

public class Spelling
{
	
	char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();
	ArrayList<String> simWords;
	int x =0;
	int lookups = 0;

		/**
			The method  puts the input word into char array and swaps every letter of the word if two letters are next to each other.
			and searches the new make up word in the  tree if it found it puts into an array List. it increments the number of lookups.
			This method was given in the assignment.
		*/	

	public void similarOne(String inputword, BinSearchTree dictionary){
	    char[] wordinchararray = inputword.toCharArray();
	    char[] tmp;
	    String[] words = new String[wordinchararray.length-1];
	    for(int i = 0; i < wordinchararray.length - 1; i++){
	        tmp = wordinchararray.clone();
	        words[i] = swap(i, i+1, tmp);
	        String foundWord = dictionary.search(words[i]);
	        lookups++;
			if (foundWord != null){
				simWords.add(foundWord);
			} 			
	    }
	}
   
    // This method swaps  characters in an array of char and returns new word (String).

	public String swap(int a, int b, char[] word){
	    char tmp = word[a];
	    word[a] = word[b];
	    word[b] = tmp;
	    return new String(word);
	}

		/**
			This method is made for when it seems a letter is replaced from the word, So all the letters of the word is replaced with the alphabet 
			one at a time, the words that are found in the tree are stored. and the lookups are  incremented.  
		*/
	public void replaced(String inputword,  BinSearchTree dictionary) {
		char[] wordinchararray = inputword.toCharArray();
		for (int x = 0; x < wordinchararray.length; x++) {
			char[] tmp = wordinchararray.clone();
			for (int y = 0; y < alphabet.length; y++) {
				tmp[x] = alphabet[y];
				String foundWord = dictionary.search(new String(tmp));
				lookups++;
				if (foundWord != null){
					simWords.add(foundWord);
						
				} 
			} 
		}
	}

	/**
		This method is made for when it seems a letter is removed from the word, So a letter of the alphabet is tries to add to the all positions 
		of the word, the words that are found in the tree are stored. and the lookups are  incremented.  
	*/

	public void removed(String inputword,  BinSearchTree dictionary) {
		for (int x = 0; x < inputword.length() + 1; x++) {
			for (int y = 0; y < alphabet.length; y++) {
				String tmp = inputword.substring(0, x) + alphabet[y] + inputword.substring(x, inputword.length());
				String foundWord = dictionary.search(tmp);
				lookups++;
				if (foundWord != null){
					simWords.add(foundWord);
				} 
			}
		}
	}

	public int NoOflookups(){ // returns number of lookups.
		return lookups;
	}
	public void emptyLookups(){ // sets the number of lookups to zero.
		lookups = 0;
	}

	/**
		This method is made for when it seems an extra letter is added to the word, it tries to removes a letter from every position of 
		the word.  words that are found in the tree are stored. and the lookups are  incremented.  
	*/
	public void added(String inputword,  BinSearchTree dictionary) {
		for (int x = 0; x < inputword.length(); x++) {
			String tmp = inputword.substring(0, x) + inputword.substring(x + 1, inputword.length());
			//System.out.println(tmp);
			String foundWord = dictionary.search(tmp);
			lookups++;
			if (foundWord != null){
				simWords.add(foundWord);	
			} 
		}
	}

/**
	This method is when a word that is looked up from the tree is not found. and it calls the above mentioned methods to possibly find the word.
	if suggestions are found it calculates and prints the time, number of suggested words found and number of lookups.
*/
	public void findWord(String input, BinSearchTree dictionary) {
		long start = System.currentTimeMillis();
		simWords = new ArrayList<String>();
		similarOne(input,  dictionary);
		replaced(input, dictionary);
		removed(input, dictionary);
		added(input,  dictionary);	
			long end = System.currentTimeMillis();
			long runningTime = end - start;
		if (simWords.size() == 0) {
			System.out.println("No suggested words for " + input + " can be found. \n");
		} else {
			System.out.println("Running Time: " + runningTime + " Millisecond");
			System.out.println(input + " Found. Suggested words are the following: \n");
			for (int x = 0; x < simWords.size(); x++) {
				System.out.print("- " + simWords.get(x) + "\n");
			}	
			x = NoOflookups();
			System.out.println("No of Lookups are: "+x);
			emptyLookups();	
		}	
	}

} // End of the class Spelling.

