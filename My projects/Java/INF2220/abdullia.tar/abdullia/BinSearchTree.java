
/**

    This class houses the methods that manipulates the tree like:
    inserting, deleting, traversing,finding, geting the hight, geting first 
    and last node(word in our case).
    it aslo houses a Node class
    
    */

public class BinSearchTree
{

    Node root;
    int totalNodes;
    int totalHightperDepth;
    double averageHightOfAllNodes;

    public BinSearchTree(String key) {
    	this.root = new Node(key, null, null); // creating the root
    }

    public void insert(String word) {   // inserting a word into tree by calling the insert method in the node class that is recursive.
            root.insert(word);
    }

    public String search(String word) { // finding the word by calling the search method in the node class that is recursive.
        Node srchword = root.search(word);
        if(srchword == null) return null;
        else return srchword.key;
    }

    public void delete(String word) { // deleting a word by calling the delete method in the node class that is recursive.
    	String ss = search(word); // first find the word if it is in the tree.
        if( ss == null){
    		System.out.println( word+ " " + "is not in the Tree");
    	}
        else if (root.key.equals(word))
        {
        	root = root.deleteNode(root);
        } 
        else root.delete(word);
    }

    public String max() { // Finds the last word by calling the max method in the node class that is recursive.
        return root.max();
    }

    public String min() { // Finds the first word by calling the min method in the node class that is recursive.
    	return root.min();
    }

    public int height() { // returns the hight of the tree.
    		return root.height(root);
    }

    public int[] nodesPerDepth() {  // returns an array containing nodes per depth
        	int[] cntr = new int[height() + 1];
        	root.nodesPerDepth(cntr, 0);
        	return cntr;
    }


        public void printStatistics(){  // prints Statistics

            System.out.println("\nThe depth/hight of the Tree is: "+ height());
            System.out.println("\nFirst wod is: " + min());
            System.out.println("\nLast wod is: " + max());
            System.out.println("\nNumber of nodes per Depth are as follows:  " );
            System.out.println("Depth" + "\t" + " Number of Nodes per Depth");
            printAvrageDepth();
            System.out.println("\nAverage height of all the nodes is:  " + averageHightOfAllNodes);
            System.out.println();

        }

        public void printAvrageDepth(){ // prints Average Depth

            int [] npd=nodesPerDepth();
    		int k = 0;
    		for(int i=0; i<npd.length;i++){
    			System.out.println(i+ "\t" + npd[i]);
                totalNodes+=npd[i];
    			totalHightperDepth+=npd[i]*i;
                //System.out.println(totalHightperDepth);
    		}
            averageHightOfAllNodes = totalHightperDepth/totalNodes;
        }

        /**
        Class Node in side the BinSearchTree
        */

    class Node
    {

    	Node leftchild;  // left subtree
    	Node rightchild; // right subtree
    	String key;      // value of the node in our case the word.

    	Node(String key, Node leftchild, Node rightchild){

    		this.key = key;
    		this.leftchild = leftchild;
    		this.rightchild = rightchild;
    	}

    	void insert(String word) { // inserting recursively
            if (word.compareTo(key) < 0) {
                if (leftchild == null) leftchild = new Node(word, null, null);
                else leftchild.insert(word);
                //System.out.println(leftchild.key);
            } else {
                if (rightchild == null) rightchild = new Node(word, null, null);
                else rightchild.insert(word);
                //System.out.println(rightchild.key);
            }
        }


        Node search(String word) { //findig the word recursively
            if (word.equals(key)) {
                return this;
            } else if (word.compareTo(key) < 0) {
                if(leftchild == null) return null;
                else return leftchild.search(word);
            
            } else {
                if(rightchild == null) return null;
                else return rightchild.search(word);     
            }   
        }

        void delete(String word) { // Deleting recursively and is not a luzy delete.
            if (word.compareTo(key) < 0) {
                if (leftchild.key.equals(word)) leftchild = deleteNode(leftchild);
                else leftchild.delete(word);
            } else {
                if (rightchild.key.equals(word)) rightchild = deleteNode(rightchild);
                else rightchild.delete(word);
            }
        }


        Node deleteNode(Node del) {
            if (del.isLeaf()) { // del does not have any children
                return null;
            } else if (!del.isFullNode()) { // del have either left or right child.
                return del.findChild();     // it return the left or right that is the only child for del.
            } else {
                String str = del.rightchild.min(); // deletes the last on the right node
                del.delete(str);
                return new Node(str, del.leftchild, del.rightchild);
            }
        }


        Node findChild() { // it return left or right child and in this case is when the parent has either left or right child. 
        	if(leftchild == null) return rightchild;
        	else return leftchild;
        }
        boolean isFullNode() {  // it returns true if the node has two children.
        	if(leftchild !=null && rightchild !=null) return true;
        	else return false;
        }

        boolean isLeaf() { // it returns true if the node does not have any children
            if(leftchild == null && rightchild == null) return true;
            else return false;
        }

        String min() { // returns first Word
            
            if(leftchild == null) return key;
            else return leftchild.min();
        }

        String max() { // returns last word
            
            if (rightchild == null) return key;
            else return rightchild.max();
        }



        int height(Node node) { // returns the hight of the tree

        	if( node == null) return -1;
        	else return 1 + Math.max(height(node.leftchild), height(node.rightchild));
        }


        private void nodesPerDepth(int[] cntr, int depth) { // calculating number of nodes per depth or per hight.
        	if(root==null)
        		return ;

               if(leftchild!=null)
                	leftchild.nodesPerDepth(cntr, depth + 1);
               if(rightchild!=null)
                	rightchild.nodesPerDepth(cntr, depth + 1);
            cntr[depth]++;
        }	
       


    } // End of Node class









}// End of BST