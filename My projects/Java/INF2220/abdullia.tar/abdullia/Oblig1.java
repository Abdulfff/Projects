

/**

    This class contains the Main method and creates an object of the reader class to call readFile method, and initializes the tree pointer to null.
*/
class Oblig1{

	public static void main(String[] args) {
			
		BinSearchTree dictionary = null;
		Reader fd = new Reader();
		fd.readFile();
	}




}

