

1. My program Compiles with "javac *java”.




2. The Main method is in Oblig1.java file.




3. Assumptions

I assumed that any input that is not word will not crash the program. i have tried with number and special character, it recognises as unfound word.



4. Peculiarities

I did not find any thing to my knowledge.

5. Status

Every thing is working properly as i know:

a. The file is read,
b. Inserted all the words into Tree (named dictionary).
c. Remove the word ‘busybody’ and re-added it.
d. Gives user interface for looking up words in the dictionary(tree).
e. Looks up the word and prints if it exists.
f. Performs spell-check by looking similar words if the word does not exist.
g. It can print help menu by pressing h.
h. When the program exits it prints out statistics.





6. Credit


	My code is influenced by chapter 4 in "Data structures and
	algorithm analysis in Java by MARK ALLEN WEISS. Third Edition." 
        and INF2220 Lecture slides.


